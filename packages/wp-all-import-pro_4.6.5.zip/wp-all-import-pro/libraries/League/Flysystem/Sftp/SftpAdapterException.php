<?php

namespace League\Flysystem\Sftp;

interface SftpAdapterException
{
}
