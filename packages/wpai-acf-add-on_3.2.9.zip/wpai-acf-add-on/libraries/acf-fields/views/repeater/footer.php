    <div class="wpallimport-clear"></div>
    <div class="switcher-target-is_variable_<?php echo str_replace(array('[',']'), '', $field_name);?>_<?php echo $field['key'];?>_no">
        <div class="input sub_input">
            <ul class="hl clearfix repeater-footer">
                <li class="right">
                    <a href="javascript:void(0);" class="acf-button delete_row" style="margin-left:15px;"><?php _e('Delete Row', 'wp_all_import_acf_add_on'); ?></a>
                </li>
                <li class="right">
                    <a class="add-row-end acf-button" href="javascript:void(0);"><?php _e("Add Row", 'wp_all_import_acf_add_on');?></a>
                </li>
            </ul>
        </div>
    </div>
</div>